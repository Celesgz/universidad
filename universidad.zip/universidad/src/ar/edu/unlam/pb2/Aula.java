package ar.edu.unlam.pb2;

public class Aula {

	private String numero;
	private Integer capacidad;

	public Aula(String numero, Integer capacidad) {
		this.numero=numero;
		this.capacidad=capacidad;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public Integer getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(Integer capacidad) {
		this.capacidad = capacidad;
	}

	
}
