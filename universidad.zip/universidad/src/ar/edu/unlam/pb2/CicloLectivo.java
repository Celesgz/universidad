package ar.edu.unlam.pb2;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CicloLectivo {
    private String id;
    private Date fechaInicio;
    private Date fechaFin;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public CicloLectivo(String id, String fechaInicio, String fechaFin) {
        this.id = id;
        try {
            this.fechaInicio = dateFormat.parse(fechaInicio);
            this.fechaFin = dateFormat.parse(fechaFin);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public boolean seSuperponeCon(CicloLectivo otroCiclo) {
        // Verificar si las fechas de inicio o fin del ciclo actual están dentro del rango del otro ciclo
        if ((fechaInicio.compareTo(otroCiclo.getFechaInicio()) >= 0 && fechaInicio.compareTo(otroCiclo.getFechaFin()) <= 0) ||
            (fechaFin.compareTo(otroCiclo.getFechaInicio()) >= 0 && fechaFin.compareTo(otroCiclo.getFechaFin()) <= 0)) {
            return true;
        }
        
        // Verificar si las fechas de inicio o fin del otro ciclo están dentro del rango del ciclo actual
        if ((otroCiclo.getFechaInicio().compareTo(fechaInicio) >= 0 && otroCiclo.getFechaInicio().compareTo(fechaFin) <= 0) ||
            (otroCiclo.getFechaFin().compareTo(fechaInicio) >= 0 && otroCiclo.getFechaFin().compareTo(fechaFin) <= 0)) {
            return true;
        }
        
        // Si no se cumple ninguna de las condiciones anteriores, no hay superposición
        return false;
    }

    public String getId() {
        return id;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }
}
