package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.List;

public class Sistema {

	private String nombre;

	private List<Materia> materias;
	private List<Alumno> alumnos;
	private List<Profesor> profesores;
	private List<CicloLectivo> ciclosLectivos;
	private List<Comision> comisiones;
	private List<Aula>aulas;

	public Sistema(String nombre) {
		this.nombre=nombre;
		this.materias = new ArrayList<>();
		this.alumnos = new ArrayList<>();
		this.profesores = new ArrayList<>();
		this.ciclosLectivos = new ArrayList<>();
		this.comisiones = new ArrayList<>();
		this.aulas=new ArrayList<>();
	}


	public void agregarMateria(Materia materia) {
		for (Materia m : materias) {
			if (m.getMateriaId().equals(materia.getMateriaId())) {
				return;
			}
		}
		materias.add(materia);
	}
	
	public void agregarAlumno(Alumno alumno) {
		for (Alumno a : alumnos) {
			if (a.getDni().equals(alumno.getDni())) {
				return;
			}
		}
     alumnos.add(alumno);
	}
	
	public void agregarProfesor(Profesor profesor) {
		for( Profesor p : profesores) {
			if(p.getDni().equals(profesor.getDni())) {
				return;
			}
		}
	profesores.add(profesor);
	}
	

	public List<Materia> getMaterias() {
		return materias;
	}

	public List<Alumno> getAlumnos() {
		return alumnos;
	}

	public List<Profesor> getProfesores() {
		return profesores;
	}

	public List<CicloLectivo> getCiclosLectivos() {
		return ciclosLectivos;
	}

	public List<Comision> getComisiones() {
		return comisiones;
	}

	public Integer cantidadMaterias() {
		return this.materias.size();
	}

	public Integer cantidadAlumnos() {
		return this.alumnos.size();
	}

	public Integer cantidadDeProfesores() {
		return this.profesores.size();
	}

	public boolean agregarCicloLectivo(CicloLectivo cicloLectivo) {
	    // Verificar si ya existe un ciclo lectivo con el mismo ID
        for (CicloLectivo existingCiclo : ciclosLectivos) {
            if (existingCiclo.getId().equals(cicloLectivo.getId())) {
                return false; // No se puede agregar, ya existe un ciclo lectivo con el mismo ID
            }
        }

        // Verificar si hay superposición de fechas con ciclos lectivos existentes
        for (CicloLectivo existeCiclo : ciclosLectivos) {
            if (cicloLectivo.seSuperponeCon(existeCiclo)) {
                return false; // No se puede agregar, hay superposición de fechas
            }
        }

        // Si no hay conflictos, agregar el ciclo lectivo y devolver true
        ciclosLectivos.add(cicloLectivo);
        return true;
    }


	public boolean agregarComision(Comision comision) {
        // Verificar si ya existe una comisión para la misma materia, ciclo lectivo y turno
        for (Comision existeComision : comisiones) {
            if (existeComision.getMateria().equals(comision.getMateria()) &&
                existeComision.getCicloLectivo().equals(comision.getCicloLectivo()) &&
                existeComision.getTurno().equals(comision.getTurno())) {
                
                existeComision.getCicloLectivo();
             // No se puede agregar, ya existe una comisión con los mismos detalles
                return false; 
            }
        }
        // Si no existe una comisión con los mismos detalles, agregar la comisión
        comisiones.add(comision);
        return true;
    }
	
	public Materia buscarMateriaPorId(String id) {
        for (Materia materia : materias) {
            if (materia.getMateriaId().equals(id)) {
                return materia;
            }
        }
        return null; // La materia no se encontró
    }


	public Boolean agregarCorrelativa(Materia materia, Materia materiaCorrelativa) {
	    Materia materia1 = buscarMateriaPorId(materia.getMateriaId());
	    Materia materia2 = buscarMateriaPorId(materiaCorrelativa.getMateriaId());

	    if (materia1 != null && materia2 != null) {
	        materia1.agregarCorrelativa(materia2);
	        return true;
	    }

	    return false;
	}


	public Boolean eliminarCorrelativa(Materia materia, Materia materiaCorrelativa) {
		Materia materia1 = buscarMateriaPorId(materia.getMateriaId());
	    Materia materia2 = buscarMateriaPorId(materiaCorrelativa.getMateriaId());
	    
	    if(materia1 !=null && materia2 !=null) {
	    	materia1.eliminarCorrelativa(materia2);
	    	return true;
	    }
		return false;
	}


	public void agregarAula(Aula aula) {
		if(buscarAulaPorID(aula.getNumero())==null) {
			this.aulas.add(aula);
		}
		
	}


	private Aula buscarAulaPorID(String numero) {
		for(Aula a: aulas) {
			if(a.getNumero().equals(numero)) {
				return a;
			}
		}
		return null;
			}


	public Integer cantidadAulas() {
		return this.aulas.size();
	}

	
	
	
	

}
