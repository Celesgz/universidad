package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.List;

public class Comision {

	private Materia materia;
	private CicloLectivo cicloLectivo;
	private String turno;
	private List<Profesor> profesores;
	private Integer idComision;
	private List<Alumno> alumnos;

	public Comision(Materia materia, CicloLectivo cicloLectivo, String turno, Integer idComision) {
		this.materia=materia;
		this.cicloLectivo=cicloLectivo;
		this.turno=turno;
		this.idComision=idComision;
		this.profesores = new ArrayList<>();
		this.alumnos = new ArrayList<>();
	}
	
	
	public boolean asignarDocente(Profesor profesor) {
		if(profesores.contains(profesor)) {
			return false;
		}
		this.profesores.add(profesor);
		return true;
	}
	
	

	public Integer getIdComision() {
		return idComision;
	}


	public void setIdComision(Integer idComision) {
		this.idComision = idComision;
	}


	public Materia getMateria() {
		return materia;
	}

	public void setMateria(Materia materia) {
		this.materia = materia;
	}

	public CicloLectivo getCicloLectivo() {
		return cicloLectivo;
	}

	public void setCicloLectivo(CicloLectivo cicloLectivo) {
		this.cicloLectivo = cicloLectivo;
	}

	public String getTurno() {
		return turno;
	}

	public void setTurno(String turno) {
		this.turno = turno;
	}

	public List<Profesor> getProfesores() {
		return profesores;
	}

	public void setProfesores(List<Profesor> profesores) {
		this.profesores = profesores;
	}


	public Integer getCantidadAlumnos() {
		
		return this.alumnos.size();
	}
	

}
