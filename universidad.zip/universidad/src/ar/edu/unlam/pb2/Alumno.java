package ar.edu.unlam.pb2;


public class Alumno extends Persona {

	private String carrera;

	public Alumno(String nombre, String apellido, String fechaNacimiento, String fechaIngreso, String carrera, Integer dni) {
		super(nombre, apellido, fechaNacimiento, fechaIngreso, dni);		
		this.carrera = carrera;
	}

	public String getCarrera() {
		return carrera;
	}

	public void setCarrera(String carrera) {
		this.carrera = carrera;
	}


}