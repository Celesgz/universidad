package ar.edu.unlam.pb2;

public class Profesor extends Persona {

	private String titulo;
	

	public Profesor( String nombre, String apellido, String fechaNacimiento, String fechaIngreso,String titulo, Integer dni) {
		super(nombre, apellido, fechaNacimiento, fechaIngreso, dni);
		this.titulo = titulo;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

}
