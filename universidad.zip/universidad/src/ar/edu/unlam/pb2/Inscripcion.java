package ar.edu.unlam.pb2;

import java.util.Date;

public class Inscripcion {

    private Alumno alumno;
    private Comision comision;
    private Date fechaInscripcion;
    

    public Inscripcion(Alumno alumno, Comision comision, Date fechaInscripcion) {
        this.alumno = alumno;
        this.comision = comision;
        this.fechaInscripcion = fechaInscripcion;
        
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    public Comision getComision() {
        return comision;
    }

    public void setComision(Comision comision) {
        this.comision = comision;
    }

    public Date getFechaInscripcion() {
        return fechaInscripcion;
    }

    public void setFechaInscripcion(Date fechaInscripcion) {
        this.fechaInscripcion = fechaInscripcion;
    }

 
}
