package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.List;

public class Materia {

	private String materiaId;
	private String materiaNombre;
	private List<Materia> correlativas;

	public Materia(String materiaId, String materiaNombre) {
	this.materiaId=materiaId;
	this.materiaNombre=materiaNombre;
	this.correlativas= new ArrayList<>();
	}
	

	

	public List<Materia> getCorrelativas() {
		return correlativas;
	}


	public void setCorrelativas(List<Materia> correlativas) {
		this.correlativas = correlativas;
	}


	public String getMateriaId() {
		return materiaId;
	}

	public void setMateriaId(String materiaId) {
		this.materiaId = materiaId;
	}

	public String getMateriaNombre() {
		return materiaNombre;
	}

	public void setMateriaNombre(String materiaNombre) {
		this.materiaNombre = materiaNombre;
	}

	public Boolean agregarCorrelativa(Materia materia) {
		if(correlativas.contains(materia)) {
			return false;
		}
		this.correlativas.add(materia);
		return true;
	}



	public Integer cantidadCorrelativas() {
		return this.correlativas.size();
	}




	public Boolean eliminarCorrelativa(Materia materia) {
		if(correlativas.contains(materia)) {
			this.correlativas.remove(materia);
			return true;
		}
		return false;
	}
	
	

}
