package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

public class TestUniversidad {

	@Test
	public void queSePuedaCrearElSistema() {
		Sistema unlam= new Sistema ("Intraconsulta");
		assertNotNull(unlam);
	}
	
	/*------------------AGREGAR MATERIA----------------*/
	@Test
	public void queSePuedaCrearUnaMateria()  {
		Sistema unlam= new Sistema ("Intraconsulta");
		String materiaId = "01";
		String materiaNombre = "Programación I";

	 Materia materia = new Materia(materiaId, materiaNombre);
	 unlam.agregarMateria(materia);
	 Integer valorEsperado=1;
	 
	 assertEquals(valorEsperado, unlam.cantidadMaterias());
	 
	}
	@Test
	public void queNoSePuedaAgregarDosMateriasConMismoID() {
		Sistema unlam = new Sistema("Intraconsulta");

		Materia materia1 = new Materia("01", "Programación I");
		Materia materia2 = new Materia("01", "Matemática");

		unlam.agregarMateria(materia1);
		unlam.agregarMateria(materia2);
		Integer valorEsperado=1;
		 
		assertEquals(valorEsperado, unlam.cantidadMaterias());
	}
	
	/*------------------AGREGAR ALUMNO----------------*/
	@Test
	public void queSePuedaAgregarUnAlumno()  {
		Sistema unlam= new Sistema ("Intraconsulta");
	String nombreAlumno = "Celeste";
	String apellidoAlumno = "Gomez";
	String fechaNacimiento= "08-05-2004";
	String fechaIngreso= "08-05-2023";
	String carrera="Desarrollo web";
	Integer dni=1111111;
	Alumno alumno=new Alumno(nombreAlumno, apellidoAlumno, fechaNacimiento, fechaIngreso, carrera, dni);

	unlam.agregarAlumno(alumno);
	Integer valorEsperado=1;
	assertEquals(valorEsperado, unlam.cantidadAlumnos());
	 
	}
	
	@Test
	public void queNoSePuedaAgregarUnAlumnoConElMismoDni()  {
	Sistema unlam= new Sistema ("Intraconsulta");
	
	Alumno alumno=new Alumno("Celeste", "Gomez", "08-05-2004", "08-05-2023", "Desarrollo web", 1111111);
	Alumno alumno2=new Alumno("Pepita", "Sanchez", "18-02-2000", "20-05-2023", "Desarrollo web", 1111111);

	unlam.agregarAlumno(alumno);
	unlam.agregarAlumno(alumno2);
	Integer valorEsperado=1;
	assertEquals(valorEsperado, unlam.cantidadAlumnos());
	
	}
	
	/*------------------AGREGAR PROFESOR----------------*/
	@Test
	public void queSePuedaAgregarUnProfesor()  {
	Sistema unlam= new Sistema ("Intraconsulta");
	String nombreProfesor = "Homero";
	String apellidoProfesor= "Simpson";
	String fechaNacimiento= "28-12-1990";
	String fechaIngreso= "09-10-2010";
	String titulo="Profesor de progra";
	Integer dni=1111111;
	Profesor profesor=new Profesor(nombreProfesor, apellidoProfesor, fechaNacimiento, fechaIngreso, titulo, dni);

	unlam.agregarProfesor(profesor);
	Integer valorEsperado=1;
	assertEquals(valorEsperado, unlam.cantidadDeProfesores());
	 
	}
	@Test
	public void queNoSePuedaAgregarDosProfesoresConElMismoDni()  {
	Sistema unlam= new Sistema ("Intraconsulta");

	Profesor profesor=new Profesor("Homero", "Simpson", "28-12-1990", "09-10-2010", "Profesor de progra", 1111111);
	Profesor profesor2=new Profesor("Bart", "Simpson", "15-09-1987", "21-01-2023", "Profesor de diseño", 1111111);
	
	unlam.agregarProfesor(profesor);
	unlam.agregarProfesor(profesor2);
	Integer valorEsperado=1;
	assertEquals(valorEsperado, unlam.cantidadDeProfesores());
	 
	}
	
	/*------------------AGREGAR CICLO ELECTIVO----------------*/
	@Test
	public void queSePuedaAgregarUnCicloLectivo() {
	    Sistema unlam = new Sistema("Intraconsulta");
	    String cicloId = "2023-01";
	    String fechaInicio = "2023-03-01";
	    String fechaFin = "2023-07-30";

	    CicloLectivo cicloLectivo = new CicloLectivo(cicloId, fechaInicio, fechaFin);
	    boolean resultado = unlam.agregarCicloLectivo(cicloLectivo);

	    assertTrue(resultado); // Verificar que se pueda agregar el ciclo lectivo
	}

	@Test
	public void queNoSePuedaAgregarDosCiclosLectivosConMismoID() {
	    Sistema unlam = new Sistema("Intraconsulta");

	    CicloLectivo ciclo1 = new CicloLectivo("2023-01", "2023-03-01", "2023-07-30");
	    CicloLectivo ciclo2 = new CicloLectivo("2023-01", "2023-03-01", "2023-07-30");

	    boolean resultado1 = unlam.agregarCicloLectivo(ciclo1);
	    boolean resultado2 = unlam.agregarCicloLectivo(ciclo2);

	    assertTrue(resultado1); // El primer ciclo debería poder agregarse
	    assertFalse(resultado2); // El segundo ciclo no debería poder agregarse
	}
	
	/*------------------AGREGAR COMISION----------------*/
	  @Test
	    public void queSePuedaAgregarUnaComision() {
		  Sistema unlam = new Sistema("Intraconsulta");
	      Materia materia = new Materia("01", "Programación I");
	      CicloLectivo cicloLectivo = new CicloLectivo("2023-01", "2023-03-01", "2023-07-30");
	      String turno = "Mañana";
	      Integer idComision=1;

	      Comision comision = new Comision(materia, cicloLectivo, turno,idComision);
	      boolean resultado = unlam.agregarComision(comision);

	        assertTrue(resultado); // Verificar que se pueda agregar la comisión
	    }
	  
	  @Test
	    public void queNoSePuedanAgregarDosComisionesIguales() {
		  Sistema unlam = new Sistema("Intraconsulta");
	      Materia materia = new Materia("01", "Programación I");
	      CicloLectivo cicloLectivo = new CicloLectivo("2023-01", "2023-03-01", "2023-07-30");
	      String turno = "Mañana";
	      Integer idComision=1;

	      Comision comision1 = new Comision(materia, cicloLectivo, turno,idComision);
	      Comision comision2 = new Comision(materia, cicloLectivo, turno,idComision);

	      boolean resultado1 = unlam.agregarComision(comision1);
	      boolean resultado2 = unlam.agregarComision(comision2);

	        assertTrue(resultado1); // La primera comisión debería poder agregarse
	        assertFalse(resultado2); // La segunda comisión no debería poder agregarse
	    }
	  
	  /*------------------AGREGAR DOCENTE A UNA COMISION----------------*/
	  @Test
	    public void queSePuedaAsignarDocentesAUnaComision() {
	        Materia materia = new Materia("01", "Programación I");
	        CicloLectivo cicloLectivo = new CicloLectivo("2023-01", "2023-03-01", "2023-07-30");
	        String turno = "Mañana";
	        Integer idComision=1;

	        Comision comision = new Comision(materia, cicloLectivo, turno,idComision);
	        Profesor profesor1 = new Profesor("Homero", "Simpson", "28-12-1990", "09-10-2010", "Profesor de progra", 1111111);
	        Profesor profesor2 = new Profesor("Marge", "Simpson", "15-09-1987", "21-01-2023", "Profesor de diseño", 2222222);

	        boolean resultado1 = comision.asignarDocente(profesor1);
	        boolean resultado2 = comision.asignarDocente(profesor2);

	        assertTrue(resultado1); // El primer profesor debería poder asignarse a la comisión
	        assertTrue(resultado2); // El segundo profesor debería poder asignarse a la comisión
	    }
	  
	  @Test
	    public void queNoSePuedaAsignarDosVecesElMismoDocenteAUnaComision() {
	        Materia materia = new Materia("01", "Programación I");
	        CicloLectivo cicloLectivo = new CicloLectivo("2023-01", "2023-03-01", "2023-07-30");
	        String turno = "Mañana";
	        Integer idComision=1;

	        Comision comision = new Comision(materia, cicloLectivo, turno,idComision);
	        Profesor profesor = new Profesor("Homero", "Simpson", "28-12-1990", "09-10-2010", "Profesor de progra", 1111111);

	        boolean resultado1 = comision.asignarDocente(profesor);
	        boolean resultado2 = comision.asignarDocente(profesor);

	        assertTrue(resultado1); // El profesor debería poder asignarse a la comisión una vez
	        assertFalse(resultado2); // El profesor no debería poder asignarse dos veces a la misma comisión
	    }
	  
	  /*------------------AGREGAR CORRELATIVA----------------*/
	  @Test
	    public void queSePuedaAgregarCorrelatividadExistente() {
		  Sistema unlam = new Sistema("Intraconsulta");
		  Materia materia = new Materia("01", "Programación I");
	      Materia materiaCorrelativa = new Materia("02", "Programación II");

	      unlam.agregarMateria(materia);
	      unlam.agregarMateria(materiaCorrelativa);
	      
	      Boolean resultado = unlam.agregarCorrelativa(materia,materiaCorrelativa);
	      Integer ve=1;
	      

	      assertTrue(resultado); // Verificar que se pueda agregar la correlatividad
	      assertEquals(ve, materia.cantidadCorrelativas()); // Verificar que la correlatividad se agregó
	    }
	  
	  @Test
	    public void queNoSePuedaAgregarCorrelatividadInexistente() {
		  Sistema unlam = new Sistema("Intraconsulta");
		  Materia materia = new Materia("01", "Programación I");
	      Materia materiaCorrelativa = new Materia("03", "Diseño");

	      unlam.agregarMateria(materia);
	      
	      
	      Boolean resultado = unlam.agregarCorrelativa(materia,materiaCorrelativa);
	      Integer ve=0;
	      

	      assertFalse(resultado); // Verificar que se pueda agregar la correlatividad
	      assertEquals(ve, materia.cantidadCorrelativas()); // Verificar que la correlatividad se agregó
	    }

	  /*------------------ELIMINAR CORRELATIVA----------------*/
	  @Test
	    public void queSePuedaEliminarCorrelatividadExistente() {
		  Sistema unlam = new Sistema("Intraconsulta");
		  Materia materia = new Materia("01", "Programación I");
	      Materia materiaCorrelativa = new Materia("02", "Programación II");

	      unlam.agregarMateria(materia);
	      unlam.agregarMateria(materiaCorrelativa);
	      unlam.agregarCorrelativa(materia,materiaCorrelativa);
	      
	      Boolean resultado = unlam.eliminarCorrelativa(materia,materiaCorrelativa);
	      Integer ve=0;
	      

	      assertTrue(resultado); 
	      assertEquals(ve, materia.cantidadCorrelativas()); 
	    }
	  
	  @Test
	    public void queNoSePuedaEliminarCorrelatividadInexistente() {
		  Sistema unlam = new Sistema("Intraconsulta");
	        Materia materia = new Materia("01", "Programación I");
	        Materia materia2 = new Materia("02", "Programación II");

	        // No agregar correlatividad, pero intentar eliminarla
	        unlam.agregarMateria(materia);
		    unlam.agregarMateria(materia2);
	        boolean resultado = materia.eliminarCorrelativa(materia2);
	        
	        Integer ve=0;

	        assertFalse(resultado); // Verificar que no se haya eliminado la correlatividad (no existía)
	        assertEquals(ve, materia.cantidadCorrelativas());  // La lista de correlativas debe seguir vacía
	    }
	  
	  /*------------------------CRAEAR UN AULA----------------------*/
	  @Test
	    public void queSePuedaCrearUnAula() {
		  Sistema unlam = new Sistema("Intraconsulta");
		  String numero="101";
		  Integer capacidad=50;
		  
	      Aula aula = new Aula(numero, capacidad);
	      
	      unlam.agregarAula(aula);
	        
	      Integer ve=1;

	      assertEquals(numero, aula.getNumero());
	      assertEquals(ve, unlam.cantidadAulas());  
	    }
	  
	  @Test
	    public void queNoSePuedaCrearUnAulaConElMismoNumero() {
		  Sistema unlam = new Sistema("Intraconsulta");
		  String numero="101";
		  Integer capacidad=50;
		  
	      Aula aula = new Aula(numero, capacidad);
	      Aula aula2 = new Aula(numero, capacidad);
	      
	      unlam.agregarAula(aula);
	      unlam.agregarAula(aula2);
	        
	      Integer ve=1;
	      
	      assertEquals(ve, unlam.cantidadAulas());  
	    }
	  
	  @Test
	  public void testInscripcionCorrecta() {
		  Sistema unlam = new Sistema("Intraconsulta");
	      // Arrange
			Alumno alumno=new Alumno("Celeste", "Gomez", "08-05-2004", "08-05-2023", "Desarrollo web", 1111111);
		    Materia materia = new Materia("01", "Programación I");
		    CicloLectivo cicloLectivo = new CicloLectivo("2023-01", "2023-03-01", "2023-07-30");
		    String turno = "Mañana";
		    Integer idComision=1;

		    Comision comision = new Comision(materia, cicloLectivo, turno,idComision);
		    Aula aula = new Aula("101", 50);
		    Integer ve=1;
		    

		    // Act
		    Inscripcion inscripcion = servicioInscripciones.inscribirAlumnoAComision(alumno.getDni(), comision.getIdComision(), new Date(2023, 8, 2));


		    assertEquals(ve, comision.getCantidadAlumnos());

	  }



}
